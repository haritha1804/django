import zmq
import datetime

class ZMQServer:
    def __init__(self, port=5555):
        self.port = port
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.REP)
        self.socket.bind(f"tcp://*:{self.port}")

    def start(self):
        print(f"Server started at port {self.port}")
        while True:
            message = self.socket.recv_string()
            if message == "TIME":
                current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                self.socket.send_string(current_time)
            else:
                self.socket.send_string("Unknown command")

if __name__ == "__main__":
    server = ZMQServer()
    server.start()
