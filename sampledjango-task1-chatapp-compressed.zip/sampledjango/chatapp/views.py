from django.shortcuts import render
from .zmq_client import ZMQClient

def index(request):
    response = None
    if request.method == "POST":
        command = request.POST.get('command')
        client = ZMQClient()
        response = client.send_request(command)

    return render(request, 'chatapp/chat.html', {'response': response})
