import zmq

class ZMQClient:
    def __init__(self, server_ip="localhost", server_port=5555):
        self.server_ip = server_ip
        self.server_port = server_port
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.REQ)
        self.socket.connect(f"tcp://{self.server_ip}:{self.server_port}")

    def send_request(self, message):
        self.socket.send_string(message)
        response = self.socket.recv_string()
        return response
